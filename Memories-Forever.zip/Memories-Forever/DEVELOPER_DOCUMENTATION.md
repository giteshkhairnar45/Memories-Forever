# Memories - Developer Documentation

## Project Overview

**Memories** is a romantic web application designed for couples to preserve and share their relationship memories. It's a single-page application (SPA) built with React and TypeScript that allows couples to upload media, write love letters, document their story, and track their relationship timeline. All data is stored locally in the browser using localStorage, making it a client-side only application with no backend requirements.

### Purpose
This application serves as a private digital scrapbook where couples can:
- Store photos, videos, and audio recordings of special moments
- Write themed love letters and apology letters to each other
- Document their relationship story chronologically
- Track how long they've been together with a live counter

### Target Audience
- Couples looking for a private, intimate way to preserve memories
- Developers learning React, TypeScript, and modern frontend patterns
- Anyone interested in building a full-featured SPA without backend infrastructure

---

## Technology Stack

### Core Technologies
- **React 18.2.0** - UI library for building component-based interfaces
- **TypeScript 5.3.3** - Type-safe JavaScript for better code quality and developer experience
- **Vite 5.1.0** - Fast build tool and development server
- **React Router DOM 6.22.0** - Client-side routing for navigation

### Development Tools
- **@vitejs/plugin-react** - Vite plugin for React support
- **@types/react** & **@types/react-dom** - TypeScript type definitions

### Styling
- **Pure CSS** - No CSS frameworks, custom romantic theme with CSS variables
- **CSS Variables** - Centralized theming system for consistent design
- **Responsive Design** - Mobile-friendly layouts with media queries

---

## Project Architecture

### Application Structure

```
src/
├── components/          # Reusable UI components
│   ├── Layout.tsx      # Main app layout with header and navigation
│   ├── ProfileSelector.tsx  # Profile selection dropdown
│   └── RelationshipCounter.tsx  # Live relationship duration counter
├── context/            # React Context providers
│   └── AuthContext.tsx  # Authentication state management
├── lib/                # Utility functions and helpers
│   └── storage.ts      # localStorage abstraction layer
├── pages/              # Page components (routes)
│   ├── Home.tsx        # Dashboard/home page
│   ├── SignIn.tsx      # Login page
│   ├── SignUp.tsx      # Registration page
│   ├── UploadMedia.tsx # Media upload form
│   ├── LoveGallery.tsx # Media gallery with filters
│   ├── OurStory.tsx    # Story chapters editor
│   └── LoveLetters.tsx # Love letter composer and viewer
├── types.ts            # TypeScript type definitions
├── App.tsx             # Main app component with routing
├── main.tsx            # Application entry point
└── index.css           # Global styles and CSS variables
```

### Design Patterns

1. **Component-Based Architecture**: UI is broken down into reusable, composable components
2. **Context API**: Global state (authentication) managed via React Context
3. **Custom Hooks**: `useAuth()` hook for accessing authentication state
4. **Protected Routes**: Route guards prevent unauthorized access
5. **Local Storage Abstraction**: Centralized storage functions for data persistence
6. **Type Safety**: Full TypeScript coverage for compile-time error checking

---

## Data Models

### Core Types (defined in `src/types.ts`)

#### ProfileId
```typescript
type ProfileId = 'partner1' | 'partner2'
```
Identifies which partner in the couple is performing an action.

#### CoupleAccount
```typescript
interface CoupleAccount {
  id: string;                    // Unique account identifier (UUID)
  username: string;               // Login username
  passwordHash: string;           // Hashed password (simple hash for demo)
  commitmentDate: string;         // ISO date string - when relationship started
  partner1: { name: string; nickname: string };
  partner2: { name: string; nickname: string };
  createdAt: string;              // Account creation timestamp
}
```

#### UserSession
```typescript
interface UserSession {
  accountId: string;              // Links to CoupleAccount
  username: string;
  commitmentDate: string;
  partner1: { name: string; nickname: string };
  partner2: { name: string; nickname: string };
  currentProfileId: ProfileId | null;  // Which partner is currently active
}
```

#### MediaItem
```typescript
interface MediaItem {
  id: string;                     // Unique media identifier
  type: 'image' | 'video' | 'audio';
  title: string;
  description: string;
  date: string;                   // ISO date - when memory occurred
  url: string;                    // Base64 data URL or blob URL
  uploadedBy: ProfileId;          // Who uploaded this
  uploadedAt: string;             // Upload timestamp
  editedBy?: ProfileId;          // Optional: who last edited
  editedAt?: string;             // Optional: last edit timestamp
}
```

#### StorySection
```typescript
interface StorySection {
  id: string;
  title: string;
  content: string;
  date: string;                  // When this chapter occurred
  author: ProfileId;             // Who wrote this section
  order: number;                 // Display order
  createdAt: string;
  updatedAt?: string;
  updatedBy?: ProfileId;
}
```

#### LoveLetter
```typescript
interface LoveLetter {
  id: string;
  type: 'love' | 'sorry';        // Letter type
  theme: LetterThemeId;          // Visual theme
  title: string;
  body: string;                   // Letter content
  from: ProfileId;               // Sender
  to: ProfileId;                 // Recipient (always the other partner)
  createdAt: string;
  isRead?: boolean;              // Optional read status
}

type LetterThemeId = 'classic' | 'rose' | 'midnight' | 'vintage' | 'minimal';
```

---

## Storage System

### LocalStorage Architecture

The application uses browser localStorage as its data persistence layer. All storage operations are abstracted through `src/lib/storage.ts`.

#### Storage Keys
- `memories_accounts` - Array of all CoupleAccount objects
- `memories_session` - Current active UserSession
- `memories_media_{accountId}` - MediaItem array for specific account
- `memories_story_{accountId}` - StorySection array for specific account
- `memories_letters_{accountId}` - LoveLetter array for specific account

#### Storage Functions

**Account Management:**
- `getAccounts()` - Retrieve all registered accounts
- `saveAccount(account)` - Save or update an account

**Session Management:**
- `getSession()` - Get current session from localStorage
- `setSession(session)` - Save or clear current session

**Media Operations:**
- `getMedia(accountId)` - Get all media items for an account
- `saveMedia(accountId, items)` - Save media array
- `deleteMedia(accountId, itemId)` - Delete a specific media item

**Story Operations:**
- `getStory(accountId)` - Get all story sections
- `saveStory(accountId, sections)` - Save story sections array

**Letter Operations:**
- `getLetters(accountId)` - Get all love letters
- `saveLetters(accountId, letters)` - Save letters array

### Storage Limitations

- **Quota**: Browser localStorage typically has a 5-10MB limit per origin
- **File Size Limits**: 
  - Images: 3MB max
  - Videos/Audio: 2MB max
- **Error Handling**: QuotaExceededError is caught and user-friendly messages displayed
- **Data Format**: All data stored as JSON strings

### Future Improvements
For production, consider migrating to:
- IndexedDB for larger storage capacity
- Backend API with database (PostgreSQL, MongoDB)
- Cloud storage (AWS S3, Cloudinary) for media files
- Proper authentication (JWT tokens, OAuth)

---

## Authentication System

### Authentication Flow

1. **Sign Up**: User creates account with username, password, commitment date, and partner names
2. **Sign In**: User logs in with username/password
3. **Profile Selection**: User selects which partner they are (Partner 1 or Partner 2)
4. **Session Persistence**: Session stored in localStorage, persists across page refreshes
5. **Logout**: Session cleared, user redirected to sign-in

### Implementation Details

**Password Hashing**: Uses a simple hash function for demo purposes. **NOT SECURE** for production.
```typescript
function simpleHash(str: string): string {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h << 5) - h + str.charCodeAt(i);
    h |= 0;
  }
  return String(Math.abs(h));
}
```

**AuthContext**: Provides global authentication state via React Context:
- `session: UserSession | null` - Current session
- `login(username, password)` - Login function
- `signUp(data)` - Registration function
- `logout()` - Logout function
- `setCurrentProfile(id)` - Switch active profile

**Protected Routes**: Routes wrapped in `<ProtectedRoute>` require authentication. Unauthenticated users redirected to `/sign-in`.

**Public-Only Routes**: Sign-in and sign-up pages wrapped in `<PublicOnly>` redirect authenticated users to home.

---

## Routing System

### Route Structure

```
/                    → Home (protected)
/sign-in             → Sign In (public only)
/sign-up             → Sign Up (public only)
/gallery             → Love Gallery (protected)
/story               → Our Story (protected)
/letters             → Love Letters (protected)
/upload              → Upload Media (protected)
/*                   → Redirect to home
```

### Route Guards

- **ProtectedRoute**: Checks for session, redirects to `/sign-in` if not authenticated
- **PublicOnly**: Redirects authenticated users to `/` to prevent access to sign-in/sign-up

### Navigation

Navigation handled via React Router's `<NavLink>` components in the Layout header. Active route highlighted with `active` class.

---

## Key Features Implementation

### 1. Relationship Counter

**Component**: `RelationshipCounter.tsx`

Displays live countdown/countup from the commitment date:
- Days, hours, minutes, seconds
- Updates every second using `setInterval`
- Formatted with leading zeros
- Styled with romantic theme

### 2. Media Upload

**Component**: `UploadMedia.tsx`

**Features:**
- File type selection (image/video/audio)
- File validation (type and size)
- Image preview before upload
- Title, description, and date fields
- Base64 encoding for storage
- Error handling for quota exceeded
- Success message with link to gallery

**File Processing:**
- Uses `FileReader.readAsDataURL()` to convert files to base64
- Stores complete data URL in localStorage
- Max sizes: 3MB images, 2MB video/audio

### 3. Love Gallery

**Component**: `LoveGallery.tsx`

**Features:**
- Grid layout with responsive columns
- Filter by media type (all/images/videos/audio)
- Lightbox modal for full-size image viewing
- Delete button (only visible to uploader)
- Auto-refresh on tab visibility change
- Empty state with call-to-action

**Media Display:**
- Images: Click to open lightbox
- Videos: Embedded `<video>` player
- Audio: Audio player with placeholder icon

### 4. Our Story

**Component**: `OurStory.tsx`

**Features:**
- Chronological story sections
- Add new chapters
- Edit existing chapters (with edit history)
- Author attribution
- Order management

### 5. Love Letters

**Component**: `LoveLetters.tsx`

**Features:**
- Two letter types: Love letters and Sorry letters
- Five visual themes: Classic, Rose, Midnight, Vintage, Minimal
- Theme-aware page styling (composer, buttons, cards match theme)
- Letter composer with template text
- Letter cards with preview
- Modal viewer for full letter
- From/To attribution

**Theme System:**
- Each theme has custom colors for:
  - Letter paper background
  - Page UI elements (buttons, composer, cards)
  - Text colors
- Theme selected via `data-theme` attribute on page container
- CSS selectors like `[data-theme="midnight"]` apply theme-specific styles

---

## Styling System

### CSS Architecture

**Global Styles** (`index.css`):
- CSS variables for colors, spacing, shadows, fonts
- Base resets and typography
- Global utility classes

**Component Styles**:
- Each component has its own `.css` file
- Scoped to component class names
- Uses CSS variables for theming

### Design Tokens

**Color Palette:**
- Rose shades: `--rose-50` through `--rose-800`
- Accent colors: `--pink-400`, `--blue-400`, `--gold`, `--lavender`
- Neutrals: `--white`, `--cream`, `--ink`, `--ink-soft`

**Spacing:**
- Border radius: `--radius` (16px), `--radius-sm` (10px), `--radius-lg` (24px)
- Shadows: `--shadow-soft`, `--shadow-card`, `--shadow-glow`

**Typography:**
- Display font: `--font-display` (Cormorant Garamond, Georgia, serif)
- Body font: `--font-body` (Quicksand, sans-serif)

**Background:**
- Gradient background with fixed attachment
- Romantic pink/rose color scheme

### Responsive Design

- Mobile-first approach
- Media queries in `Layout.css` for mobile breakpoints
- Flexible grid layouts
- Touch-friendly button sizes

---

## Development Setup

### Prerequisites
- Node.js (v16 or higher)
- npm or yarn package manager

### Installation

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

### Development Server
- Runs on `http://localhost:5173` (Vite default)
- Hot Module Replacement (HMR) enabled
- Fast refresh for React components

### Build Process
1. TypeScript compilation (`tsc -b`)
2. Vite build (bundling, minification, optimization)
3. Output to `dist/` directory

---

## Code Quality & Best Practices

### TypeScript Usage
- Strict type checking enabled
- All components typed
- Interfaces for all data models
- Type-safe props and state

### Component Patterns
- Functional components with hooks
- Separation of concerns (UI, logic, data)
- Reusable components
- Props interfaces for type safety

### Error Handling
- Try-catch blocks in storage operations
- User-friendly error messages
- Graceful degradation (empty arrays on parse errors)
- Quota exceeded detection and messaging

### Performance Considerations
- React.memo potential (not currently used, but could optimize)
- Lazy loading possible for routes (not implemented)
- Image optimization via base64 (trade-off: larger storage)
- Efficient re-renders via Context optimization

---

## Known Limitations & Future Enhancements

### Current Limitations

1. **No Backend**: All data stored locally, lost if browser data cleared
2. **Simple Password Hashing**: Not secure for production use
3. **Storage Quota**: Limited by browser localStorage (5-10MB)
4. **No Media Compression**: Files stored as-is, consuming space quickly
5. **No Cloud Sync**: Data not synced across devices
6. **No User Management**: Single account per browser
7. **No Search**: Can't search through memories or letters
8. **No Export**: Can't export data for backup

### Suggested Enhancements

**Short-term:**
- Add data export/import functionality
- Implement search/filter for gallery
- Add image compression before storage
- Improve error messages and validation
- Add loading states for async operations

**Medium-term:**
- Migrate to IndexedDB for larger storage
- Add media thumbnails for better performance
- Implement proper password hashing (bcrypt)
- Add data backup to cloud storage
- Create mobile app version (React Native)

**Long-term:**
- Backend API with database
- User authentication with JWT
- Cloud media storage (AWS S3, Cloudinary)
- Real-time sync between devices
- Email notifications for new letters
- Print-friendly letter views
- Calendar view for memories
- Relationship milestones tracking

---

## Testing Considerations

### Manual Testing Checklist

**Authentication:**
- [ ] Sign up creates account
- [ ] Sign in with correct credentials
- [ ] Sign in with wrong password fails
- [ ] Profile selection works
- [ ] Logout clears session
- [ ] Protected routes redirect when not authenticated

**Media Upload:**
- [ ] File selection works
- [ ] File validation (type, size)
- [ ] Image preview displays
- [ ] Upload saves to storage
- [ ] Quota exceeded error displays
- [ ] Success message shows

**Gallery:**
- [ ] Media displays correctly
- [ ] Filters work (all/image/video/audio)
- [ ] Lightbox opens for images
- [ ] Delete button only shows for uploader
- [ ] Delete removes item
- [ ] Gallery refreshes on tab focus

**Letters:**
- [ ] Theme selection changes page colors
- [ ] Letter saves correctly
- [ ] Letter cards display
- [ ] Modal viewer works
- [ ] From/To attribution correct

**Story:**
- [ ] Sections save
- [ ] Edit history tracked
- [ ] Order maintained

---

## Deployment

### Static Site Deployment

Since this is a client-side only application, it can be deployed to any static hosting:

**Options:**
- **Vercel**: `vercel deploy`
- **Netlify**: Drag and drop `dist/` folder
- **GitHub Pages**: Push `dist/` to gh-pages branch
- **AWS S3 + CloudFront**: Upload to S3 bucket
- **Firebase Hosting**: `firebase deploy`

### Build Output
- All assets in `dist/` directory
- `index.html` as entry point
- Bundled JavaScript and CSS
- No server-side rendering needed

### Environment Considerations
- No environment variables currently used
- Can add `.env` files for API keys if backend added
- CORS not an issue (no external API calls)

---

## Contributing Guidelines

### Code Style
- Use TypeScript for all new files
- Follow existing component structure
- Use CSS modules or component-scoped CSS
- Comment complex logic
- Use descriptive variable names

### Git Workflow
1. Create feature branch
2. Make changes
3. Test thoroughly
4. Commit with descriptive messages
5. Push and create pull request

### Adding New Features
1. Define types in `types.ts`
2. Add storage functions in `storage.ts` if needed
3. Create component in `pages/` or `components/`
4. Add route in `App.tsx`
5. Add navigation link in `Layout.tsx`
6. Style with component CSS file

---

## Troubleshooting

### Common Issues

**Media not saving:**
- Check browser console for errors
- Verify localStorage quota not exceeded
- Ensure file size under limits (3MB images, 2MB video/audio)
- Check that profile is selected

**Gallery not showing new items:**
- Refresh page
- Check localStorage in DevTools
- Verify accountId matches
- Check filter settings

**Styling issues:**
- Clear browser cache
- Verify CSS files loaded
- Check CSS variable definitions
- Inspect element for class names

**TypeScript errors:**
- Run `npm run build` to see all errors
- Check type imports
- Verify interface definitions match usage

---

## License & Credits

This is a demo/educational project. Feel free to use, modify, and learn from it.

### Fonts Used
- **Cormorant Garamond**: Display/heading font (Google Fonts)
- **Quicksand**: Body font (Google Fonts)

### Inspiration
Built as a romantic memory-keeping application for couples.

---

## Contact & Support

For questions or issues:
1. Check this documentation
2. Review code comments
3. Inspect browser DevTools
4. Check localStorage data structure

---

**Last Updated**: February 2025
**Version**: 1.0.0
**Maintainer**: Development Team
