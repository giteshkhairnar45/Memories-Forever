# How to Run — Our Memories

This guide walks you through running the **Our Memories** couple website on your machine, step by step.

---

## Prerequisites

Before you start, make sure you have:

| Requirement | What to check |
|-------------|----------------|
| **Node.js** | Version **18** or newer (recommended: 20 LTS). [Download](https://nodejs.org/) if needed. |
| **npm** | Comes with Node.js. Check with `npm -v` in a terminal. |

**Check your versions:**

```bash
node -v
npm -v
```

You should see something like `v20.x.x` and `10.x.x` (or similar). If you get "command not found", install Node.js first.

---

## 1. Open the project folder

Open a terminal (PowerShell, Command Prompt, or your IDE terminal) and go to the project folder:

```bash
cd D:\code\Memories
```

*(Replace with your actual path if you cloned or copied the project elsewhere.)*

---

## 2. Install dependencies

Install all required packages (React, Vite, TypeScript, etc.):

```bash
npm install
```

- This reads `package.json` and installs everything into the `node_modules` folder.
- You only need to run this **once** per machine (or after pulling new dependencies).
- If you see errors, check that you have internet access and that Node.js is installed correctly.

---

## 3. Run the app in development mode

Start the development server:

```bash
npm run dev
```

You should see output similar to:

```
  VITE v5.x.x  ready in xxx ms

  ➜  Local:   http://localhost:5173/
  ➜  press h + enter to show help
```

- The server stays running until you stop it (**Ctrl+C** in the terminal).
- Code changes will auto-reload in the browser (hot module replacement).

---

## 4. Open the app in your browser

1. Open your browser (Chrome, Edge, Firefox, etc.).
2. Go to: **http://localhost:5173**

You should see the Our Memories website. From there you can sign up, sign in, and use all features (gallery, story, love letters, etc.).

---

## 5. Stop the development server

In the terminal where `npm run dev` is running, press:

- **Ctrl+C** (Windows/Linux) or **Cmd+C** (macOS)

The server will stop and you can run other commands in that terminal.

---

## Building for production

When you want to create a version you can deploy (e.g. to a web host):

### Build

```bash
npm run build
```

- This compiles TypeScript and bundles the app with Vite.
- Output goes to the **`dist`** folder (static HTML, JS, and CSS).

### Preview the production build locally

To test the built app on your machine:

```bash
npm run preview
```

- Serves the contents of `dist` (often on http://localhost:4173).
- Stop with **Ctrl+C** when done.

---

## Quick reference

| Goal | Command |
|------|--------|
| Install dependencies | `npm install` |
| Run development server | `npm run dev` |
| Open in browser | http://localhost:5173 |
| Build for production | `npm run build` |
| Preview production build | `npm run preview` |
| Stop server | **Ctrl+C** in terminal |

---

## Troubleshooting

### "Port 5173 is already in use"

Another app is using that port. You can:

- Close the other app using the port, or  
- Set a different port when running Vite, for example:

  ```bash
  npx vite --port 3000
  ```
  Then open http://localhost:3000

### "npm: command not found" or "node: command not found"

Node.js is not installed or not on your PATH. Install it from [nodejs.org](https://nodejs.org/) and restart the terminal.

### Blank page or errors after opening localhost:5173

- Make sure `npm run dev` is still running and shows no errors.
- Try a hard refresh: **Ctrl+Shift+R** (or **Cmd+Shift+R** on Mac).
- Check the browser’s Developer Console (F12) for error messages.

### Changes don’t appear in the browser

- Save the file and wait a moment; Vite should reload.
- If not, stop the dev server (Ctrl+C) and run `npm run dev` again.

### Data (memories, letters, etc.) disappeared

Data is stored in the browser’s **localStorage** (no backend). It can be lost if you:

- Clear site data or cookies for localhost
- Use a different browser or a private/incognito window
- Use a different device

For a permanent setup you’d use a backend and database; this app is designed for local/front-end use.

---

## Summary

1. **Prerequisites:** Node.js 18+ and npm.  
2. **Setup:** `cd` to the project folder → `npm install`.  
3. **Run:** `npm run dev` → open **http://localhost:5173**.  
4. **Production:** `npm run build` then `npm run preview` to test the build.

For more about the project (features, tech stack), see [README.md](README.md).
