# Our Memories — Couple Website

A romantic website for couples to save daily memories forever. Built with React, TypeScript, and Vite.

## Features

- **Secured sign up / sign in** for one couple account
- **Two profiles** (Partner 1 & Partner 2) with optional nicknames — see who uploaded or edited what
- **Relationship counter** on the home page: days, hours, minutes, seconds since your commitment date
- **Upload media**: images, videos, and audio with title, description, and date
- **Love Gallery**: browse all media with filters
- **Our Story**: add and edit chapters (how it started, how it's going) with author/editor attribution
- **Love letters & sorry letters**: write to each other with themed, editable templates (Classic, Rose, Midnight, Vintage, Minimal)

## Run locally

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview
```

## Data storage

Data is stored in the browser’s **localStorage** (no backend). Each couple’s media, story, and letters are keyed by account. For a production app you would replace this with a secure backend and database.

## Tech stack

- React 18 + TypeScript
- React Router 6
- Vite 5
- CSS with a romantic theme (pink, rose, blue accents)
