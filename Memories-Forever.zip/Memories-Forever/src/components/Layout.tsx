import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import ProfileSelector from './ProfileSelector';
import './Layout.css';

export default function Layout() {
  const { session, logout, setCurrentProfile } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/sign-in');
  };

  const displayName = session?.currentProfileId
    ? session[session.currentProfileId]?.nickname || session[session.currentProfileId]?.name
    : 'Choose who you are';

  return (
    <div className="layout">
      <header className="header">
        <h1>Our Memories</h1>
        <nav className="nav">
          <NavLink to="/" end className={({ isActive }) => isActive ? 'active' : ''}>Home</NavLink>
          <NavLink to="/gallery" className={({ isActive }) => isActive ? 'active' : ''}>Love Gallery</NavLink>
          <NavLink to="/story" className={({ isActive }) => isActive ? 'active' : ''}>Our Story</NavLink>
          <NavLink to="/letters" className={({ isActive }) => isActive ? 'active' : ''}>Letters</NavLink>
          <NavLink to="/upload" className={({ isActive }) => isActive ? 'active' : ''}>Upload</NavLink>
        </nav>
        <div className="header-actions">
          <ProfileSelector
            session={session!}
            onSelect={setCurrentProfile}
          />
          <span className="profile-badge">{displayName}</span>
          <button type="button" className="logout-btn" onClick={handleLogout}>
            Sign out
          </button>
        </div>
      </header>
      <main className="main">
        <Outlet />
      </main>
    </div>
  );
}
