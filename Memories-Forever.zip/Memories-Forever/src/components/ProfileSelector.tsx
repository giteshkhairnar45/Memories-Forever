import { useState, useRef, useEffect } from 'react';
import type { UserSession, ProfileId } from '../types';
import './ProfileSelector.css';

interface Props {
  session: UserSession;
  onSelect: (id: ProfileId | null) => void;
}

export default function ProfileSelector({ session, onSelect }: Props) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const p1 = session.partner1;
  const p2 = session.partner2;
  const current = session.currentProfileId;

  return (
    <div className="profile-selector" ref={ref}>
      <button
        type="button"
        className="profile-selector-trigger"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
      >
        {current === 'partner1' && `${p1.nickname || p1.name}`}
        {current === 'partner2' && `${p2.nickname || p2.name}`}
        {!current && 'Select profile'}
        <span className="profile-selector-arrow">▼</span>
      </button>
      {open && (
        <div className="profile-selector-dropdown">
          <button
            type="button"
            onClick={() => {
              onSelect('partner1');
              setOpen(false);
            }}
            className={current === 'partner1' ? 'active' : ''}
          >
            <span className="profile-avatar">💕</span>
            {p1.nickname ? `${p1.nickname} (${p1.name})` : p1.name}
          </button>
          <button
            type="button"
            onClick={() => {
              onSelect('partner2');
              setOpen(false);
            }}
            className={current === 'partner2' ? 'active' : ''}
          >
            <span className="profile-avatar">💖</span>
            {p2.nickname ? `${p2.nickname} (${p2.name})` : p2.name}
          </button>
        </div>
      )}
    </div>
  );
}
