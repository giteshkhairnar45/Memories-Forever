import { useState, useEffect } from 'react';
import './RelationshipCounter.css';

interface Props {
  commitmentDate: string; // ISO date
}

function pad(n: number) {
  return n < 10 ? `0${n}` : String(n);
}

export default function RelationshipCounter({ commitmentDate }: Props) {
  const [diff, setDiff] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const start = new Date(commitmentDate).getTime();
    const tick = () => {
      const now = Date.now();
      if (now < start) {
        setDiff({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }
      let sec = Math.floor((now - start) / 1000);
      const days = Math.floor(sec / 86400);
      sec %= 86400;
      const hours = Math.floor(sec / 3600);
      sec %= 3600;
      const minutes = Math.floor(sec / 60);
      sec %= 60;
      setDiff({ days, hours, minutes, seconds: sec });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [commitmentDate]);

  return (
    <div className="counter-wrap">
      <p className="counter-label">Together for</p>
      <div className="counter-units">
        <div className="counter-unit">
          <span className="counter-value">{diff.days}</span>
          <span className="counter-unit-label">Days</span>
        </div>
        <div className="counter-unit">
          <span className="counter-value">{pad(diff.hours)}</span>
          <span className="counter-unit-label">Hours</span>
        </div>
        <div className="counter-unit">
          <span className="counter-value">{pad(diff.minutes)}</span>
          <span className="counter-unit-label">Minutes</span>
        </div>
        <div className="counter-unit">
          <span className="counter-value">{pad(diff.seconds)}</span>
          <span className="counter-unit-label">Seconds</span>
        </div>
      </div>
    </div>
  );
}
