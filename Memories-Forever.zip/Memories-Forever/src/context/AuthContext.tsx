import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { UserSession, ProfileId, CoupleAccount } from '../types';
import { getAccounts, getSession, setSession, saveAccount } from '../lib/storage';

// Simple hash for demo - in production use proper password hashing
function simpleHash(str: string): string {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h << 5) - h + str.charCodeAt(i);
    h |= 0;
  }
  return String(Math.abs(h));
}

interface AuthContextValue {
  session: UserSession | null;
  login: (username: string, password: string) => { ok: boolean; error?: string };
  signUp: (data: {
    username: string;
    password: string;
    commitmentDate: string;
    partner1Name: string;
    partner1Nickname: string;
    partner2Name: string;
    partner2Nickname: string;
  }) => { ok: boolean; error?: string };
  logout: () => void;
  setCurrentProfile: (id: ProfileId | null) => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSessionState] = useState<UserSession | null>(null);

  useEffect(() => {
    setSessionState(getSession());
  }, []);

  const persistSession = useCallback((s: UserSession | null) => {
    setSessionState(s);
    setSession(s);
  }, []);

  const login = useCallback(
    (username: string, password: string) => {
      const accounts = getAccounts();
      const account = accounts.find((a) => a.username.toLowerCase() === username.trim().toLowerCase());
      if (!account) return { ok: false, error: 'Account not found.' };
      const hash = simpleHash(password);
      if (account.passwordHash !== hash) return { ok: false, error: 'Wrong password.' };
      const userSession: UserSession = {
        accountId: account.id,
        username: account.username,
        commitmentDate: account.commitmentDate,
        partner1: account.partner1,
        partner2: account.partner2,
        currentProfileId: null,
      };
      persistSession(userSession);
      return { ok: true };
    },
    [persistSession]
  );

  const signUp = useCallback(
    (data: {
      username: string;
      password: string;
      commitmentDate: string;
      partner1Name: string;
      partner1Nickname: string;
      partner2Name: string;
      partner2Nickname: string;
    }) => {
      const accounts = getAccounts();
      if (accounts.some((a) => a.username.toLowerCase() === data.username.trim().toLowerCase())) {
        return { ok: false, error: 'This username is already taken.' };
      }
      const account: CoupleAccount = {
        id: crypto.randomUUID(),
        username: data.username.trim(),
        passwordHash: simpleHash(data.password),
        commitmentDate: data.commitmentDate,
        partner1: { name: data.partner1Name, nickname: data.partner1Nickname },
        partner2: { name: data.partner2Name, nickname: data.partner2Nickname },
        createdAt: new Date().toISOString(),
      };
      saveAccount(account);
      const userSession: UserSession = {
        accountId: account.id,
        username: account.username,
        commitmentDate: account.commitmentDate,
        partner1: account.partner1,
        partner2: account.partner2,
        currentProfileId: null,
      };
      persistSession(userSession);
      return { ok: true };
    },
    [persistSession]
  );

  const logout = useCallback(() => {
    persistSession(null);
  }, [persistSession]);

  const setCurrentProfile = useCallback(
    (id: ProfileId | null) => {
      if (!session) return;
      const next: UserSession = { ...session, currentProfileId: id };
      persistSession(next);
    },
    [session, persistSession]
  );

  const value: AuthContextValue = {
    session,
    login,
    signUp,
    logout,
    setCurrentProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
