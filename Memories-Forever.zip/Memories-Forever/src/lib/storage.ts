import type { CoupleAccount, MediaItem, StorySection, LoveLetter } from '../types';

const KEYS = {
  ACCOUNTS: 'memories_accounts',
  SESSION: 'memories_session',
  MEDIA: 'memories_media',
  STORY: 'memories_story',
  LETTERS: 'memories_letters',
} as const;

export function getAccounts(): CoupleAccount[] {
  try {
    const raw = localStorage.getItem(KEYS.ACCOUNTS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveAccount(account: CoupleAccount): void {
  const accounts = getAccounts().filter((a) => a.id !== account.id);
  accounts.push(account);
  localStorage.setItem(KEYS.ACCOUNTS, JSON.stringify(accounts));
}

export function getSession() {
  try {
    const raw = localStorage.getItem(KEYS.SESSION);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setSession(session: object | null): void {
  if (session === null) localStorage.removeItem(KEYS.SESSION);
  else localStorage.setItem(KEYS.SESSION, JSON.stringify(session));
}

function getStorageKey(key: string, accountId: string) {
  return `${key}_${accountId}`;
}

export function getMedia(accountId: string): MediaItem[] {
  try {
    const raw = localStorage.getItem(getStorageKey(KEYS.MEDIA, accountId));
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveMedia(accountId: string, items: MediaItem[]): void {
  localStorage.setItem(getStorageKey(KEYS.MEDIA, accountId), JSON.stringify(items));
}

export function deleteMedia(accountId: string, itemId: string): MediaItem[] {
  const items = getMedia(accountId).filter((m) => m.id !== itemId);
  localStorage.setItem(getStorageKey(KEYS.MEDIA, accountId), JSON.stringify(items));
  return items;
}

export function getStory(accountId: string): StorySection[] {
  try {
    const raw = localStorage.getItem(getStorageKey(KEYS.STORY, accountId));
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveStory(accountId: string, sections: StorySection[]): void {
  localStorage.setItem(getStorageKey(KEYS.STORY, accountId), JSON.stringify(sections));
}

export function getLetters(accountId: string): LoveLetter[] {
  try {
    const raw = localStorage.getItem(getStorageKey(KEYS.LETTERS, accountId));
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveLetters(accountId: string, letters: LoveLetter[]): void {
  localStorage.setItem(getStorageKey(KEYS.LETTERS, accountId), JSON.stringify(letters));
}
