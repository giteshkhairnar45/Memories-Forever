import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import RelationshipCounter from '../components/RelationshipCounter';
import './Home.css';

export default function Home() {
  const { session } = useAuth();

  return (
    <div className="home-page">
      <div className="home-hero">
        <h2>Forever Yours</h2>
        <p>Every moment with you is a memory worth keeping.</p>
      </div>
      <RelationshipCounter commitmentDate={session!.commitmentDate} />
      <div className="home-quick-links">
        <Link to="/upload">
          <span className="icon">📤</span>
          Upload memory
        </Link>
        <Link to="/gallery">
          <span className="icon">🖼️</span>
          Love Gallery
        </Link>
        <Link to="/story">
          <span className="icon">📖</span>
          Our Story
        </Link>
        <Link to="/letters">
          <span className="icon">💌</span>
          Letters
        </Link>
      </div>
      {!session?.currentProfileId && (
        <p className="profile-reminder">
          <strong>Tip:</strong> Choose who you are from the menu above so we know who uploaded or edited content.
        </p>
      )}
    </div>
  );
}
