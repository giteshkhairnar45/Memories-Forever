import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getMedia, deleteMedia } from '../lib/storage';
import type { MediaItem, MediaType } from '../types';
import './LoveGallery.css';

export default function LoveGallery() {
  const { session } = useAuth();
  const [items, setItems] = useState<MediaItem[]>([]);
  const [filter, setFilter] = useState<MediaType | 'all'>('all');
  const [lightbox, setLightbox] = useState<MediaItem | null>(null);

  const refreshItems = useCallback(() => {
    if (!session?.accountId) return;
    setItems(getMedia(session.accountId));
  }, [session?.accountId]);

  useEffect(() => {
    refreshItems();
  }, [refreshItems]);

  useEffect(() => {
    const onVisibility = () => { if (document.visibilityState === 'visible') refreshItems(); };
    document.addEventListener('visibilitychange', onVisibility);
    return () => document.removeEventListener('visibilitychange', onVisibility);
  }, [refreshItems]);

  const handleDelete = (e: React.MouseEvent, item: MediaItem) => {
    e.preventDefault();
    e.stopPropagation();
    if (!session?.accountId || session.currentProfileId !== item.uploadedBy) return;
    if (!window.confirm(`Delete "${item.title}"?`)) return;
    const next = deleteMedia(session.accountId, item.id);
    setItems(next);
  };

  const filtered = filter === 'all' ? items : items.filter((i) => i.type === filter);
  const getByName = (id: 'partner1' | 'partner2') => session?.[id]?.nickname || session?.[id]?.name || id;

  return (
    <div className="gallery-page">
      <h2>Love Gallery</h2>
      <div className="gallery-filters">
        <button className={filter === 'all' ? 'active' : ''} onClick={() => setFilter('all')}>All</button>
        <button className={filter === 'image' ? 'active' : ''} onClick={() => setFilter('image')}>Images</button>
        <button className={filter === 'video' ? 'active' : ''} onClick={() => setFilter('video')}>Videos</button>
        <button className={filter === 'audio' ? 'active' : ''} onClick={() => setFilter('audio')}>Audio</button>
      </div>
      {filtered.length === 0 ? (
        <div className="gallery-empty">
          <div className="icon">🖼️</div>
          <p>No memories yet. <Link to="/upload">Upload your first memory</Link>.</p>
        </div>
      ) : (
        <div className="gallery-grid">
          {filtered.map((item) => (
            <div key={item.id} className="gallery-card">
              <div className="media-preview">
                {item.type === 'image' && <img src={item.url} alt={item.title} onClick={() => setLightbox(item)} />}
                {item.type === 'video' && <video src={item.url} controls />}
                {item.type === 'audio' && (
                  <>
                    <div className="audio-placeholder">🎵</div>
                    <audio src={item.url} controls />
                  </>
                )}
              </div>
              <div className="info">
                <div className="info-header">
                  <h3>{item.title}</h3>
                  {session?.currentProfileId === item.uploadedBy && (
                    <button
                      type="button"
                      className="delete-memory-btn"
                      onClick={(e) => handleDelete(e, item)}
                      title="Delete this memory"
                      aria-label="Delete memory"
                    >
                      Delete
                    </button>
                  )}
                </div>
                {item.description && <p className="desc">{item.description}</p>}
                <p className="meta">
                  {new Date(item.date).toLocaleDateString()} · <span className="by">By {getByName(item.uploadedBy)}</span>
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
      {lightbox && (
        <div className="lightbox" onClick={() => setLightbox(null)}>
          <button type="button" className="close" onClick={() => setLightbox(null)} aria-label="Close">×</button>
          {lightbox.type === 'image' && <img src={lightbox.url} alt={lightbox.title} onClick={(e) => e.stopPropagation()} />}
          {lightbox.type === 'video' && <video src={lightbox.url} controls autoPlay onClick={(e) => e.stopPropagation()} />}
        </div>
      )}
    </div>
  );
}
