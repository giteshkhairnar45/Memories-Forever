import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { getLetters, saveLetters } from '../lib/storage';
import type { LoveLetter, LetterThemeId, ProfileId } from '../types';
import './LoveLetters.css';

const THEMES: { id: LetterThemeId; label: string }[] = [
  { id: 'classic', label: 'Classic' },
  { id: 'rose', label: 'Rose' },
  { id: 'midnight', label: 'Midnight' },
  { id: 'vintage', label: 'Vintage' },
  { id: 'minimal', label: 'Minimal' },
];

const DEFAULT_LOVE = `My dearest,

I just wanted to tell you how much you mean to me. Every day with you feels like a gift.

Love always.`;
const DEFAULT_SORRY = `My love,

I'm sorry. I never want to hurt you. You deserve the world.

With love and regret.`;

export default function LoveLetters() {
  const { session } = useAuth();
  const [letters, setLetters] = useState<LoveLetter[]>([]);
  const [type, setType] = useState<'love' | 'sorry'>('love');
  const [theme, setTheme] = useState<LetterThemeId>('classic');
  const [title, setTitle] = useState('');
  const [body, setBody] = useState(DEFAULT_LOVE);
  const [viewing, setViewing] = useState<LoveLetter | null>(null);
  const accountId = session?.accountId;
  const profileId = session?.currentProfileId;

  useEffect(() => {
    if (!accountId) return;
    setLetters(getLetters(accountId));
  }, [accountId]);

  useEffect(() => {
    setBody(type === 'love' ? DEFAULT_LOVE : DEFAULT_SORRY);
  }, [type]);

  const saveLetter = () => {
    if (!accountId || !profileId) return;
    const to: ProfileId = profileId === 'partner1' ? 'partner2' : 'partner1';
    const newLetter: LoveLetter = {
      id: crypto.randomUUID(),
      type,
      theme,
      title: title.trim() || (type === 'love' ? 'A love letter' : 'I\'m sorry'),
      body: body.trim(),
      from: profileId,
      to,
      createdAt: new Date().toISOString(),
    };
    const next = [newLetter, ...letters];
    saveLetters(accountId, next);
    setLetters(next);
    setTitle('');
    setBody(type === 'love' ? DEFAULT_LOVE : DEFAULT_SORRY);
  };

  const getByName = (id: ProfileId) => session?.[id]?.nickname || session?.[id]?.name || id;

  return (
    <div className="letters-page" data-theme={theme}>
      <h2>Letters to each other</h2>
      <p className="subtitle">Write a love letter or say sorry with a beautiful theme.</p>

      <div className="letter-composer">
        <div className="letters-actions">
          <button type="button" className={type === 'love' ? 'active' : ''} onClick={() => setType('love')}>
            💌 Love letter
          </button>
          <button type="button" className={type === 'sorry' ? 'active' : ''} onClick={() => setType('sorry')}>
            💝 I'm sorry
          </button>
        </div>
        <div className="letter-themes">
          {THEMES.map((t) => (
            <button
              key={t.id}
              type="button"
              className={theme === t.id ? 'active' : ''}
              onClick={() => setTheme(t.id)}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="field">
          <label>Title (optional)</label>
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. For my love" />
        </div>
        <div className="field">
          <label>Your message (edit the text below)</label>
          <textarea value={body} onChange={(e) => setBody(e.target.value)} />
        </div>
        <button type="button" className="submit" onClick={saveLetter} disabled={!profileId}>
          Send letter
        </button>
      </div>

      <h3 className="letters-section-title">Your letters</h3>
      {letters.length === 0 ? (
        <div className="letter-empty">
          <div className="icon">💌</div>
          <p>No letters yet. Write one above!</p>
        </div>
      ) : (
        <div className="letter-cards">
          {letters.map((letter) => (
            <div key={letter.id} className="letter-card" onClick={() => setViewing(letter)}>
              <div className={`letter-paper theme-${letter.theme}`}>
                <h4>{letter.title}</h4>
                <p className="body">{letter.body.slice(0, 150)}{letter.body.length > 150 ? '...' : ''}</p>
              </div>
              <div className="meta">
                From <span className="from">{getByName(letter.from)}</span> to {getByName(letter.to)} · {new Date(letter.createdAt).toLocaleDateString()}
              </div>
            </div>
          ))}
        </div>
      )}

      {viewing && (
        <div className="letter-modal-overlay" onClick={() => setViewing(null)}>
          <div className="letter-modal" onClick={(e) => e.stopPropagation()} style={{ position: 'relative' }}>
            <button type="button" className="close-btn" onClick={() => setViewing(null)} aria-label="Close">×</button>
            <div className={`letter-paper theme-${viewing.theme}`}>
              <h4>{viewing.title}</h4>
              <p className="body">{viewing.body}</p>
            </div>
            <div className="meta">
              From <span className="from">{getByName(viewing.from)}</span> to {getByName(viewing.to)} · {new Date(viewing.createdAt).toLocaleString()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
