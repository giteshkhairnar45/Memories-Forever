import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { getStory, saveStory } from '../lib/storage';
import type { StorySection, ProfileId } from '../types';
import './OurStory.css';

export default function OurStory() {
  const { session } = useAuth();
  const [sections, setSections] = useState<StorySection[]>([]);
  const [modal, setModal] = useState<'add' | 'edit' | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formDate, setFormDate] = useState(new Date().toISOString().slice(0, 10));

  const accountId = session?.accountId;
  const profileId = session?.currentProfileId;

  useEffect(() => {
    if (!accountId) return;
    setSections(getStory(accountId).sort((a, b) => a.order - b.order));
  }, [accountId]);

  const saveSections = (next: StorySection[]) => {
    if (!accountId) return;
    saveStory(accountId, next);
    setSections([...next].sort((a, b) => a.order - b.order));
  };

  const getByName = (id: ProfileId) => session?.[id]?.nickname || session?.[id]?.name || id;

  const openAdd = () => {
    setFormTitle('');
    setFormContent('');
    setFormDate(new Date().toISOString().slice(0, 10));
    setEditingId(null);
    setModal('add');
  };

  const openEdit = (s: StorySection) => {
    setFormTitle(s.title);
    setFormContent(s.content);
    setFormDate(s.date);
    setEditingId(s.id);
    setModal('edit');
  };

  const handleSave = () => {
    if (!profileId) return;
    const now = new Date().toISOString();
    if (editingId) {
      const next = sections.map((s) =>
        s.id === editingId
          ? {
              ...s,
              title: formTitle.trim() || s.title,
              content: formContent.trim(),
              date: formDate,
              updatedAt: now,
              updatedBy: profileId,
            }
          : s
      );
      saveSections(next);
    } else {
      const newSection: StorySection = {
        id: crypto.randomUUID(),
        title: formTitle.trim() || 'Untitled',
        content: formContent.trim(),
        date: formDate,
        author: profileId,
        order: sections.length,
        createdAt: now,
      };
      saveSections([...sections, newSection]);
    }
    setModal(null);
  };

  return (
    <div className="story-page">
      <h2>Our Story</h2>
      <p className="subtitle">How it started & how it&apos;s going</p>
      <div className="story-intro">
        Every love story is beautiful, but ours is our favorite.
      </div>
      {sections.length === 0 ? (
        <div className="story-empty">
          <div className="icon">📖</div>
          <p>No chapters yet. Add the first one!</p>
          <button type="button" className="story-add-btn" onClick={openAdd} style={{ marginTop: '1rem' }}>
            Add chapter
          </button>
        </div>
      ) : (
        <>
          <div className="story-sections">
            {sections.map((s) => (
              <div key={s.id} className="story-section-card">
                <h3>{s.title}</h3>
                <p className="content">{s.content}</p>
                <p className="meta">
                  {new Date(s.date).toLocaleDateString()} · Written by <span className="by">{getByName(s.author)}</span>
                  {s.updatedAt && (
                    <> · Last edited by <span className="by">{getByName(s.updatedBy!)}</span></>
                  )}
                </p>
                {profileId && (
                  <button type="button" onClick={() => openEdit(s)} style={{ fontSize: '0.85rem', color: 'var(--rose-600)', marginTop: '0.5rem' }}>
                    Edit
                  </button>
                )}
              </div>
            ))}
          </div>
          <div className="story-add">
            <button type="button" className="story-add-btn" onClick={openAdd} disabled={!profileId}>
              Add chapter
            </button>
          </div>
        </>
      )}
      {modal && (
        <div className="story-modal-overlay" onClick={() => setModal(null)}>
          <div className="story-modal" onClick={(e) => e.stopPropagation()}>
            <h3>{editingId ? 'Edit chapter' : 'New chapter'}</h3>
            <div className="field">
              <label>Title</label>
              <input value={formTitle} onChange={(e) => setFormTitle(e.target.value)} placeholder="e.g. How we met" />
            </div>
            <div className="field">
              <label>Date</label>
              <input type="date" value={formDate} onChange={(e) => setFormDate(e.target.value)} />
            </div>
            <div className="field">
              <label>Content</label>
              <textarea value={formContent} onChange={(e) => setFormContent(e.target.value)} placeholder="Tell your story..." />
            </div>
            <div className="actions">
              <button type="button" className="primary" onClick={handleSave} disabled={!profileId}>Save</button>
              <button type="button" className="secondary" onClick={() => setModal(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
