import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './SignIn.css';

export default function SignIn() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const result = login(username.trim(), password);
    setLoading(false);
    if (result.ok) navigate('/');
    else setError(result.error || 'Login failed.');
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="deco-hearts">♥ ♥ ♥</div>
        <h1>Welcome Back</h1>
        <p className="subtitle">Sign in to your couple account</p>
        <form className="auth-form" onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="username">Username</label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              required
              autoComplete="username"
            />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              autoComplete="current-password"
            />
          </div>
          {error && <p className="error">{error}</p>}
          <button type="submit" className="submit" disabled={loading}>
            Sign in
          </button>
        </form>
        <p className="auth-footer">
          Don&apos;t have an account? <Link to="/sign-up">Create one</Link>
        </p>
      </div>
    </div>
  );
}
