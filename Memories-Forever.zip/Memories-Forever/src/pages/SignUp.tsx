import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './SignIn.css';
import './SignUp.css';

export default function SignUp() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [commitmentDate, setCommitmentDate] = useState('');
  const [partner1Name, setPartner1Name] = useState('');
  const [partner1Nickname, setPartner1Nickname] = useState('');
  const [partner2Name, setPartner2Name] = useState('');
  const [partner2Nickname, setPartner2Nickname] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { signUp } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!commitmentDate) {
      setError('Please choose your commitment date.');
      return;
    }
    if (!partner1Name.trim() || !partner2Name.trim()) {
      setError('Please enter both partners\' names.');
      return;
    }
    setLoading(true);
    const result = signUp({
      username: username.trim(),
      password,
      commitmentDate,
      partner1Name: partner1Name.trim(),
      partner1Nickname: partner1Nickname.trim(),
      partner2Name: partner2Name.trim(),
      partner2Nickname: partner2Nickname.trim(),
    });
    setLoading(false);
    if (result.ok) navigate('/');
    else setError(result.error || 'Sign up failed.');
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="deco-hearts">♥ ♥ ♥</div>
        <h1>Start Your Story</h1>
        <p className="subtitle">Create your couple account</p>
        <form className="auth-form" onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="username">Username</label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              required
              autoComplete="username"
            />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              autoComplete="new-password"
              minLength={6}
            />
          </div>

          <div className="commitment-field">
            <label htmlFor="commitmentDate">Our commitment date</label>
            <input
              id="commitmentDate"
              type="date"
              value={commitmentDate}
              onChange={(e) => setCommitmentDate(e.target.value)}
              required
            />
          </div>

          <p className="signup-section-title">Partner 1 (e.g. you)</p>
          <div className="signup-grid">
            <div className="field">
              <label htmlFor="p1name">Name</label>
              <input
                id="p1name"
                type="text"
                value={partner1Name}
                onChange={(e) => setPartner1Name(e.target.value)}
                placeholder="Name"
                required
              />
            </div>
            <div className="field">
              <label htmlFor="p1nick">Nickname from partner</label>
              <input
                id="p1nick"
                type="text"
                value={partner1Nickname}
                onChange={(e) => setPartner1Nickname(e.target.value)}
                placeholder="e.g. Honey, Baby"
              />
            </div>
          </div>

          <p className="signup-section-title">Partner 2 (e.g. your love)</p>
          <div className="signup-grid">
            <div className="field">
              <label htmlFor="p2name">Name</label>
              <input
                id="p2name"
                type="text"
                value={partner2Name}
                onChange={(e) => setPartner2Name(e.target.value)}
                placeholder="Name"
                required
              />
            </div>
            <div className="field">
              <label htmlFor="p2nick">Nickname from partner</label>
              <input
                id="p2nick"
                type="text"
                value={partner2Nickname}
                onChange={(e) => setPartner2Nickname(e.target.value)}
                placeholder="e.g. Sweetheart, Love"
              />
            </div>
          </div>

          {error && <p className="error">{error}</p>}
          <button type="submit" className="submit" disabled={loading}>
            Create account
          </button>
        </form>
        <p className="auth-footer">
          Already have an account? <Link to="/sign-in">Sign in</Link>
        </p>
      </div>
    </div>
  );
}
