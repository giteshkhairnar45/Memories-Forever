import { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getMedia, saveMedia } from '../lib/storage';
import type { MediaItem, MediaType } from '../types';
import './UploadMedia.css';

const ACCEPT: Record<MediaType, string> = {
  image: 'image/*',
  video: 'video/*',
  audio: 'audio/*',
};

export default function UploadMedia() {
  const { session } = useAuth();
  const [type, setType] = useState<MediaType>('image');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const profileId = session?.currentProfileId;
  const accountId = session?.accountId;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    setError('');
    if (!f) return;
    const validTypes: Record<MediaType, string[]> = {
      image: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
      video: ['video/mp4', 'video/webm'],
      audio: ['audio/mpeg', 'audio/wav', 'audio/ogg', 'audio/webm'],
    };
    if (!validTypes[type].includes(f.type)) {
      setError(`Please choose a valid ${type} file.`);
      return;
    }
    const maxMb = type === 'image' ? 3 : 2;
    if (f.size > maxMb * 1024 * 1024) {
      setError(`File should be under ${maxMb}MB so it saves reliably.`);
      return;
    }
    setFile(f);
    if (type === 'image') {
      const url = URL.createObjectURL(f);
      setPreviewUrl(url);
    } else {
      setPreviewUrl(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!profileId || !accountId) {
      setError('Please select who you are from the menu above.');
      return;
    }
    if (!file) {
      setError('Please choose a file.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const dataUrl = reader.result as string;
        const items = getMedia(accountId);
        const newItem: MediaItem = {
          id: crypto.randomUUID(),
          type,
          title: title.trim() || file.name,
          description: description.trim(),
          date,
          url: dataUrl,
          uploadedBy: profileId,
          uploadedAt: new Date().toISOString(),
        };
        saveMedia(accountId, [newItem, ...items]);
        setSaved(true);
        setTitle('');
        setDescription('');
        setDate(new Date().toISOString().slice(0, 10));
        setFile(null);
        setPreviewUrl(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
        setTimeout(() => setSaved(false), 3000);
      } catch (err) {
        const isQuota = err instanceof DOMException && (err.name === 'QuotaExceededError' || err.code === 22);
        setError(isQuota
          ? 'Storage full. Try a smaller file (e.g. under 2MB) or delete some memories from the gallery.'
          : 'Failed to save. Please try again.');
      }
    };
    reader.onerror = () => setError('Failed to read file. Please try again.');
    reader.readAsDataURL(file);
  };

  const clearFile = () => {
    setFile(null);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="upload-page">
      <h2>Upload a memory</h2>
      <form className="upload-form" onSubmit={handleSubmit}>
        <div className="field">
          <label>Type</label>
          <div className="type-tabs">
            {(['image', 'video', 'audio'] as const).map((t) => (
              <button
                key={t}
                type="button"
                className={type === t ? 'active' : ''}
                onClick={() => {
                  setType(t);
                  clearFile();
                }}
              >
                {t === 'image' && '🖼️ Image'}
                {t === 'video' && '🎬 Video'}
                {t === 'audio' && '🎵 Audio'}
              </button>
            ))}
          </div>
        </div>
        <div className="field">
          <label htmlFor="title">Title</label>
          <input
            id="title"
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Give this memory a title"
          />
        </div>
        <div className="field">
          <label htmlFor="desc">Description</label>
          <textarea
            id="desc"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="What makes this moment special?"
          />
        </div>
        <div className="field">
          <label htmlFor="date">Date of memory</label>
          <input
            id="date"
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </div>
        <div className="field">
          <label>File</label>
          <div
            className={`file-zone ${file ? 'has-file' : ''}`}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept={ACCEPT[type]}
              onChange={handleFileChange}
            />
            {file ? (
              <>
                {previewUrl && type === 'image' && (
                  <img src={previewUrl} alt="" style={{ maxWidth: '100%', maxHeight: 200, marginBottom: 8, borderRadius: 8 }} />
                )}
                <p>{file.name}</p>
                <button type="button" onClick={(e) => { e.stopPropagation(); clearFile(); }} style={{ marginTop: 8, fontSize: '0.85rem', color: 'var(--rose-600)' }}>Remove</button>
              </>
            ) : (
              <p>Click to choose {type} file (max {type === 'image' ? 3 : 2}MB)</p>
            )}
          </div>
          <p className="hint">Stored locally in this browser.</p>
        </div>
        {error && <p className="error">{error}</p>}
        {saved && (
          <p className="save-success">
            Memory saved. <Link to="/gallery">View in gallery</Link>
          </p>
        )}
        <button type="submit" className="submit" disabled={!file || !profileId}>
          Save memory
        </button>
      </form>
    </div>
  );
}
