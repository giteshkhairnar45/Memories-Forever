export type ProfileId = 'partner1' | 'partner2';

export interface CoupleAccount {
  id: string;
  username: string;
  passwordHash: string; // in real app use proper hashing
  commitmentDate: string; // ISO date
  partner1: { name: string; nickname: string };
  partner2: { name: string; nickname: string };
  createdAt: string;
}

export interface UserSession {
  accountId: string;
  username: string;
  commitmentDate: string;
  partner1: { name: string; nickname: string };
  partner2: { name: string; nickname: string };
  currentProfileId: ProfileId | null; // which profile is "you" this session
}

export type MediaType = 'image' | 'video' | 'audio';

export interface MediaItem {
  id: string;
  type: MediaType;
  title: string;
  description: string;
  date: string; // ISO date
  url: string; // base64 or blob URL for demo
  uploadedBy: ProfileId;
  uploadedAt: string;
  editedBy?: ProfileId;
  editedAt?: string;
}

export interface StorySection {
  id: string;
  title: string;
  content: string;
  date: string;
  author: ProfileId;
  order: number;
  createdAt: string;
  updatedAt?: string;
  updatedBy?: ProfileId;
}

export type LetterThemeId = 'classic' | 'rose' | 'midnight' | 'vintage' | 'minimal';

export interface LoveLetter {
  id: string;
  type: 'love' | 'sorry';
  theme: LetterThemeId;
  title: string;
  body: string;
  from: ProfileId;
  to: ProfileId;
  createdAt: string;
  isRead?: boolean;
}
